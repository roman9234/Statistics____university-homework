from random import random
import matplotlib.pyplot as plt


def generate_numbers(x0, a, b, m, n):
    numbers = []
    x = x0
    for i in range(n):
        x = (a * x + b) % m
        numbers.append(x / m)
        #numbers.append(random())
    return numbers


def generate_sequence(n):
    sequence = []
    random_numbers = generate_numbers(1, 22695477, 1, 2 ** 32, n)
    a = 0
    b = 10
    for i in range(n):
        x = (b - a) * random_numbers[i] + a
        sequence.append(x)
    return sequence


def relative_frequencies(sequence, a, b, m):
    frequencies = [0] * m
    sequence_step = (b - a) / m
    left_border = a
    right_border = a + sequence_step
    for i in range(m):
        for j in sequence:
            if left_border <= j < right_border:
                frequencies[i] += 1
        left_border += sequence_step
        right_border += sequence_step
    return frequencies


def test1(sequence, n):
    m = sum(sequence) / n
    x_2 = 0
    for i in range(n):
        x_2 += sequence[i]**2
    d = ((x_2 / n) - m ** 2) * (n / (n - 1))
    print("Экспериментальное М:", m, "Теоретическое M:", 5, "\nЭкспериментальное D:", d, "Теоретическое D:", 100/12, "\n")


def test2(sequence, n):
    for i in range(n):
        for j in range(i + 1, n):
            if sequence[i] == sequence[j]:
                return j - i
    return "unable to identify period\n"


n = [10 ** 2, 10 ** 3, 10 ** 4, 10 ** 5]
for i in range(4):
    sequence = generate_sequence(n[i])
    test1(sequence, n[i])
    print(test2(sequence, n[i]))

    xdata = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    ydata = relative_frequencies(sequence, 0, 10, 10)
    plt.bar(xdata, ydata)
    plt.show()

