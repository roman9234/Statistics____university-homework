import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm


def normal_distribution(x, M, e):
    return (1 / (e * np.sqrt(2 * np.pi))) * np.exp(-((x - M) ** 2) / (2 * e ** 2))


def task1():
    # Задаем диапазон значений x для плотности вероятности
    x_values_density = np.linspace(5, 15, 100)

    # Вычисляем плотности вероятности для каждого случая
    density1 = norm.pdf(x_values_density, 10, 1)
    density2 = norm.pdf(x_values_density, 10, 0.5)
    density3 = norm.pdf(x_values_density, 12, 1)
    density4 = norm.pdf(x_values_density, 10, 2)

    # Построение графика плотности вероятности
    plt.figure(figsize=(10, 6))
    plt.plot(x_values_density, density1, label='M=10, e=1', color='blue')
    plt.plot(x_values_density, density2, label='M=10, e=1/2', color='orange')
    plt.plot(x_values_density, density3, label='M=12, e=1', color='green')
    plt.plot(x_values_density, density4, label='M=10, e=2', color='red')

    # Настройка графика плотности вероятности
    plt.title('График плотности вероятности нормального распределения')
    plt.xlabel('x')
    plt.ylabel('Плотность вероятности')
    plt.legend()
    plt.grid()
    plt.show()


def task2():
    # Задаем диапазон значений x для функции распределения
    x_values_cdf = np.linspace(0, 20, 1000)

    # Вычисляем функцию распределения для M=10, e=2
    cdf_values = norm.cdf(x_values_cdf, loc=10, scale=2)

    # Построение графика функции распределения
    plt.figure(figsize=(10, 6))
    plt.plot(x_values_cdf, cdf_values, label='CDF: M=10, e=2', color='purple')

    # Настройка графика функции распределения
    plt.title('Функция распределения для нормального распределения (M=10, e=2)')
    plt.xlabel('x')
    plt.ylabel('F(x)')
    plt.xlim(0, 20)
    plt.ylim(0, 1)
    plt.legend()
    plt.grid()
    plt.show()

# Моделирование нормального закона распределения
def inverse_transform_sampling(cdf_values, x_values, N):
    # Генерация равномерно распределенных случайных чисел
    uniform_random_numbers = np.random.rand(N)

    # Инициализация массива для нормально распределенных значений
    simulated_values = np.zeros(N)

    # Генерация нормально распределенных значений с использованием метода обратной функции
    for i in range(N):
        # Находим индекс, где CDF превышает случайное число
        index = np.searchsorted(cdf_values, uniform_random_numbers[i])

        # Проверяем, чтобы индекс не выходил за пределы массива
        if index == len(cdf_values):
            index -= 1

        simulated_values[i] = x_values[index]

    return simulated_values

# Число экспериментов
N_values = [10 ** 3, 10 ** 4, 10 ** 5, 10 ** 6]
errors = []

# Построение гистограмм относительных частот для различных значений N
for N in N_values:
    simulated_data = inverse_transform_sampling(cdf_values, x_values_cdf, N)

    # Построение гистограммы для каждого N
    plt.figure(figsize=(10, 6))
    plt.hist(simulated_data, bins=100, density=True, alpha=0.5, color='purple', edgecolor='black')

    # Настройка графика
    plt.title(f'Гистограмма относительных частот симуляции нормального распределения (N={N})')
    plt.xlabel('x')
    plt.ylabel('Относительная частота')
    plt.grid()
    plt.show()

    # Вычисление средней квадратичной погрешности
    theoretical_density = norm.pdf(x_values_cdf, 10, 2)
    simulated_density, _ = np.histogram(simulated_data, bins=100, density=True)

    # Интерполяция теоретической плотности на тех же интервалах
    bin_centers = 0.5 * (x_values_cdf[:-1] + x_values_cdf[1:])
    theoretical_density_interpolated = np.interp(bin_centers, x_values_cdf, theoretical_density)

    # Убедимся, что размеры совпадают
    min_length = min(len(simulated_density), len(theoretical_density_interpolated))
    mse = np.mean((simulated_density[:min_length] - theoretical_density_interpolated[:min_length]) ** 2)
    errors.append(np.sqrt(mse))  # СКП

# Построение графика зависимости СКП от числа экспериментов
plt.figure(figsize=(10, 6))
plt.plot(N_values, errors, marker='o')
plt.xscale('log')
plt.title('Зависимость средней квадратичной погрешности от числа экспериментов')
plt.xlabel('Число экспериментов (N)')
plt.ylabel('Средняя квадратичная погрешность (СКП)')
plt.grid()
plt.show()