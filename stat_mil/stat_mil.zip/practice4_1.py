from random import random
import matplotlib.pyplot as plt
import numpy as np


def na(n, p):
    m = 0
    for i in range(1, n):
        u = random()
        if u < p:
            m += 1
    w = m/n
    return w


def generate_sequence(n_i, n, p):
    sequence = []
    for i in range(n_i):
        sequence.append(na(n, p))
    return sequence


def define_error(sequences, n):
    m_array = []
    d_array = []
    sigma_array = []
    for i in range(len(n)):
        m = sum(sequences[i]) / n[i]
        x_2 = 0
        for j in range(n[i]):
            x_2 += sequences[i][j] ** 2
        d = ((x_2 / n[i]) - m ** 2) * (n[i] / (n[i] - 1))
        sigma = np.sqrt(d)

        m_array.append(m)
        d_array.append(d)
        sigma_array.append(sigma)

    return m_array, d_array, sigma_array


def relative_frequencies(sequence, a, b, m):
    frequencies = [0] * m
    sequence_step = (b - a) / m
    left_border = a
    right_border = a + sequence_step
    for i in range(m):
        for j in sequence:
            if left_border <= j < right_border:
                frequencies[i] += 1
        frequencies[i] = frequencies[i] / len(sequence)
        left_border += sequence_step
        right_border += sequence_step
    return frequencies


n_i = [10, 20, 50, 100, 200, 500, 10 ** 3]
n = [50, 100, 200]
p = 0.1
for i in range(len(n)):
    sequences, m_array, sigma_array = [], [], []
    for j in range(len(n_i)):
        sequences.append(generate_sequence(n_i[j], n[i], p))
    m_array, d_array, sigma_array = define_error(sequences, n_i)
    for j in range(len(n_i)):
        frequencies = relative_frequencies(sequences[j], 0, 1, 100)

        xdata = np.arange(0.0, 1, 0.01)
        ydata = frequencies
        plt.bar(xdata, ydata, width=0.01, edgecolor='black', linewidth=0.1)
        plt.title(f'Гистограмма относительных частот для {n_i[j]} элементов с шагом {n[i]}')

        x = np.arange(0.0, 1, 0.01)
        y_exp = []
        y_exp_normalized = []
        for g in range(len(x)):
            y_exp.append(1 / (sigma_array[j] * np.sqrt(2 * np.pi)) * np.exp(-0.5 * ((x[g] - m_array[j]) / sigma_array[j]) ** 2))
        for y in y_exp:
            y_exp_normalized.append(y / np.max(y_exp) * np.max(frequencies))
        plt.plot(x, y_exp_normalized, label='Функция плотности распределения для нормального закона (экспериментальные значения).', color='r')
        plt.show()

        # Площади гистограмм
        area = 0
        for g in range(len(frequencies)):
            area += frequencies[g]

        print(f'Для {n_i[j]} элементов c шагом {n[i]}:')
        print(f"Мат. ожидание: {m_array[j]}\n"
              f"Дисперсия: {d_array[j]}\n"
              f"Среднее квадратичное отклонение: {sigma_array[j]}\n")
        print("Площадь гистограмм:", area)
        print("Площадь под экспериментальным графиком:", np.trapezoid(y_exp, x))
        print('----------------------------------------------------------------')

