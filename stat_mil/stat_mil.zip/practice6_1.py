from random import random

import scipy.stats as sc
import matplotlib.pyplot as plt
import numpy as np


def probab_den_func(m_a, s_a):
    x = [i / 100 for i in range(2000)]
    for i in range(len(m_a)):
        rv = sc.lognorm(loc=m_a[i], s=s_a[i])
        pdf = rv.pdf(x)
        plt.plot(x, pdf, label=f'M = {m_a[i]}, S = {s_a[i]}')

    plt.grid()
    plt.legend()
    plt.show()


def cum_distrib_func():
    x = [i / 100 for i in range(2000)]
    rv = sc.lognorm(loc=0, s=1)
    cdf = rv.cdf(x)
    plt.plot(x, cdf)

    plt.grid()
    plt.title("M=0, S=1")
    plt.show()


def get_arg(F, min_arg, max_arg, value, eps):
    while abs((max_arg - min_arg) / max_arg) > eps:
        mid_arg = (max_arg + min_arg) / 2
        mid_val = F(mid_arg)
        if mid_val > value:
            max_arg = mid_arg
        else:
            min_arg = mid_arg

    return (min_arg + max_arg) / 2


def get_tab_f(F, min_arg, max_arg, points_count):
    min_val = F(min_arg)
    max_val = F(max_arg)
    d_val = (max_val - min_val) / (points_count - 1)

    y_tab = [0] * points_count
    x_tab = [0] * points_count

    y_tab[0] = min_val
    x_tab[0] = min_arg

    for i in range(1, points_count - 1):
        y_tab[i] = min_val + d_val * i
        x_tab[i] = get_arg(F, min_arg, max_arg, y_tab[i], 10 ** (-15))

    y_tab[points_count - 1] = max_val
    x_tab[points_count - 1] = max_arg

    return x_tab, y_tab


def lognormal_cdf(x, mean, std):
    return sc.lognorm.cdf(x, loc=mean, s=std)


def tab_func_():
    m = 0
    sigma = 1
    Min = 0
    Max = 20
    TabSize = 101

    XTab, YTab = get_tab_f(lambda x: lognormal_cdf(x, m, sigma), Min, Max, TabSize)

    plt.plot(XTab, YTab, label='CDF (кус. - лин. апрокс.)')
    plt.title("Функция распределения вероятностей")
    plt.xlabel("XTab")
    plt.ylabel("YTab")
    plt.grid(True)
    plt.legend()
    plt.show()

    return XTab, YTab


def model_n(XTab, YTab, p):
    for i in range(1, len(XTab)):
        if YTab[i - 1] <= p <= YTab[i]:
            y = ((p - YTab[i]) / (YTab[i - 1] - YTab[i]) * XTab[i - 1]
                 + (p - YTab[i - 1]) / (YTab[i] - YTab[i - 1]) * XTab[i])
            if y is None:
                y = 0
            return y
    return 0


def print_minmax(sequence):
    y_min = min(sequence)
    y_max = max(sequence)
    print(f'Для числа экспериментов N = {len(sequence)}: min = {y_min}, max = {y_max}\n------------------------')


def create_sequence(XTab, YTab, N):
    sequence = []
    for i in range(N):
        sequence.append(model_n(XTab, YTab, random()))
    return sequence


def calculate_rmse(sequence, m, sigma):
    # Теоретическая плотность
    x_values = np.linspace(min(sequence), max(sequence), 100)
    theoretical_density = sc.lognorm.pdf(x_values, loc=m, s=sigma)

    # Гистограмма экспериментальных данных
    hist, bin_edges = np.histogram(sequence, bins=100, density=True)
    bin_centers = 0.5 * (bin_edges[1:] + bin_edges[:-1])

    hist_density = np.interp(bin_centers, x_values, theoretical_density)

    # Расчет СКП
    rmse = np.sqrt(np.mean((hist - hist_density) ** 2))
    return rmse


m_a = [0, 0, 0]
s_a = [1, 2, 1 / 2]

probab_den_func(m_a, s_a)
cum_distrib_func()
xtab, ytab = tab_func_()

exp_number = [10 ** 3, 10 ** 4, 10 ** 5, 10 ** 6]
rmse_results = []
for n in exp_number:
    sequence = create_sequence(xtab, ytab, n)
    print_minmax(sequence)

    plt.figure(figsize=(10, 6))
    plt.hist(sequence, bins=100, density=True, alpha=0.5, color='purple', edgecolor='black')

    plt.title(f'Гистограмма относительных частот симуляции нормального распределения (N={n})')
    plt.xlabel('x')
    plt.ylabel('Относительная частота')
    plt.grid()
    plt.show()

    # Расчет СКП
    rmse = calculate_rmse(sequence, 0, 1)
    rmse_results.append(rmse)
    print(f'SKП для N={n}: {rmse}')

# Построение графика зависимости СКП от числа экспериментов
plt.figure(figsize=(10, 6))
plt.plot(exp_number, rmse_results, marker='o')
plt.xscale('log')
plt.title('Зависимость средней квадратичной погрешности от числа экспериментов')
plt.xlabel('Число экспериментов (логарифмическая шкала)')
plt.ylabel('Средняя квадратичная погрешность')
plt.grid()
plt.show()
