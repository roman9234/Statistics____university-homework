# ВАРИАНТ 2
# генеральное среднее a, S - параметры, используемые в данном распределении

import numpy as np
import scipy.stats as sp
import matplotlib.pyplot as plt


def define_characteristics(sequence):
    m = sum(sequence) / len(sequence)
    x_2 = 0

    for digit in sequence:
        x_2 += digit ** 2

    d = (x_2 / len(sequence) - m ** 2) * (len(sequence) / (len(sequence) - 1) )
    sigma = np.sqrt(d)

    return m, d, sigma

def general_mean(p, sequence_mean, sigma, n):
    norm_quantile = sp.norm.ppf(1 - p / 2)
    norm_borders = (sequence_mean - (norm_quantile * sigma / np.sqrt(n)),
                    sequence_mean + (norm_quantile * sigma / np.sqrt(n)))

    student_quantile = sp.t.ppf(1 - p / 2, n - 1)
    student_borders = (sequence_mean - (student_quantile * sigma / np.sqrt(n)),
                       sequence_mean + (student_quantile * sigma / np.sqrt(n)))

    return [norm_borders, student_borders]

def general_disp(p, n, sigma):
    borders = ((n - 1) * (sigma ** 2) / sp.chi2.ppf(1 - p / 2, df=n - 1),
               (n - 1) * (sigma ** 2) / sp.chi2.ppf(p / 2, df=n - 1))
    return borders


n = [4, 6, 10, 12]
probability = [0.1, 0.05, 0.02, 0.01]
a_1 = [9.577, 12.628, 11.003, 12.512]
a_2 = [12.718, 6.167, 9.919, 12.095, 5.811, 5.706]
a_3 = [12.016, 9.259, 17.345, 5.909, 13.687, 6.507, 13.619, 5.948, 12.475, 7.663]
a_4 = [11.896, 12.354, 5.359, 13.891, 10.17, 9.255,
       16.561, 10.498, 9.716, 14.094, 9.558, 18.491]
all_array = []
all_array.append(a_1)
all_array.append(a_2)
all_array.append(a_3)
all_array.append(a_4)

for p in probability:
    m, d, sigma_array = [], [], []
    borders_general_mean_norm = []
    borders_general_mean_stud = []
    borders_general_disp = []
    print("Для вероятности p = ", p)

    for a in all_array:
        # Расчёт мат ожидания, дисперсии, сред.квадрат. отклонения для каждой заданной вероятности
        mat, disp, sigma = define_characteristics(a)
        m.append(mat)
        d.append(disp)
        sigma_array.append(sigma)
        # Расчёт границ доверительного интервала для генерального среднего
        norm_mean_borders, stud_mean_borders = general_mean(p=p, sequence_mean=mat, sigma=sigma, n=len(a))
        borders_general_mean_norm.append(norm_mean_borders)
        borders_general_mean_stud.append(stud_mean_borders)
        # Расчёт границ доверительного интервала для дисперсии
        disp_borders = general_disp(p=p, n=len(a), sigma=sigma)
        borders_general_disp.append(disp_borders)

        print(f"При n = {len(a)}:\n"
              f"M = {mat}, S = {sigma},\n"
              f"M_max (norm) = {norm_mean_borders[1]}, M_min (norm) = {norm_mean_borders[0]},\n"
              f"S_max = {np.sqrt(disp_borders[1])}, S_min = {np.sqrt(disp_borders[0])}\n"
              f"M_max (stud) = {stud_mean_borders[1]}, M_min (stud) = {stud_mean_borders[0]}\n\n")

    print("----------------------------------------------------------------")

    ns = [len(x) for x in all_array]
    mat_sred = sum(m) / len(m)
    sigma_sred = np.sqrt( (3 * (sigma_array[0] ** 2) + 5 *
                           (sigma_array[1] ** 2) + 9 *
                           (sigma_array[2] ** 2) + 11 *
                           (sigma_array[3] ** 2) ) / 8)

    min_mean_norm = [x[0] for x in borders_general_mean_norm]
    max_mean_norm = [x[1] for x in borders_general_mean_norm]
    min_mean_stud = [x[0] for x in borders_general_mean_stud]
    max_mean_stud = [x[1] for x in borders_general_mean_stud]

    min_disp = [np.sqrt(x[0]) for x in borders_general_disp]
    max_disp = [np.sqrt(x[1]) for x in borders_general_disp]

    plt.plot( ns, min_mean_norm, label="M_min[i]_Norm", linestyle="--")
    plt.plot(ns, max_mean_norm, label="M_max[i]_Norm", linestyle="--")
    plt.plot(ns, [mat_sred] * len(ns), label="M_s[i]", linestyle="-.")
    plt.plot(ns, m, label="M[i]", lw=2.5)
    plt.title(f"Доверительные интервалы мат.ожидания \n (квантили нормального распределение) p = {p}")
    plt.legend()
    plt.xlim(left=4, right=12)
    plt.grid()
    plt.show()

    plt.plot(ns, min_mean_stud, label="M_min[i]_Student", linestyle="--")
    plt.plot(ns, max_mean_stud, label="M_max[i]_Student", linestyle="--")
    plt.plot(ns, m, label="M[i]", lw=2.5)
    plt.title(f"Доверительные интервалы мат.ожидания \n (квантили распределения Стьюдента) p = {p}")
    plt.legend()
    plt.xlim(left=4, right=12)
    plt.grid()
    plt.show()

    plt.plot(ns, min_disp, label="S_min[i]", linestyle="--")
    plt.plot(ns, max_disp, label="S_max[i]", linestyle="--")
    plt.plot(ns, [sigma_sred] * len(ns), label="S_s[i]", linestyle="-.")
    plt.plot(ns, sigma_array, label="S[i]", lw=2.5)
    plt.title(f"Доверительные интервалы для сред.квадратичного отклонения \n p = {p}")
    plt.legend()
    plt.xlim(left=4, right=12)
    plt.grid()
    plt.show()