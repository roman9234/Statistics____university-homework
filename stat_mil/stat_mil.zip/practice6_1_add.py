# генеральное среднее a, S - параметры, используемые в данном распределении

import numpy as np
import scipy.stats as sp
import matplotlib.pyplot as plt

from practice6_1 import create_sequence, tab_func_


def define_characteristics(sequence):
    m = sum(sequence) / len(sequence)
    x_2 = 0

    for digit in sequence:
        x_2 += digit ** 2

    d = (x_2 / len(sequence) - m ** 2) * (len(sequence) / (len(sequence) - 1))
    sigma = np.sqrt(d)

    return m, d, sigma


def general_mean(p, sequence_mean, sigma, n):
    norm_quantile = sp.lognorm.ppf(1 - p / 2, sigma)
    norm_borders = (sequence_mean - (norm_quantile * sigma / np.sqrt(n)),
                    sequence_mean + (norm_quantile * sigma / np.sqrt(n)))

    # student_quantile = sp.t.ppf(1 - p / 2, n - 1)
    # student_borders = (sequence_mean - (student_quantile * sigma / np.sqrt(n)),
    #                    sequence_mean + (student_quantile * sigma / np.sqrt(n)))

    # return [norm_borders, student_borders]
    return norm_borders


def general_disp(p, n, sigma):
    borders = ((n - 1) * (sigma ** 2) / sp.chi2.ppf(1 - p / 2, df=n - 1),
               (n - 1) * (sigma ** 2) / sp.chi2.ppf(p / 2, df=n - 1))
    return borders


n = [5, 10, 15, 30, 40, 50]
probability = [0.1, 0.05, 0.02, 0.01]

xtab, ytab = tab_func_()

all_array = []
for i in n:
    all_array.append(create_sequence(xtab, ytab, i))

for p in probability:
    m, d, sigma_array = [], [], []
    borders_general_mean_lognorm = []
    # borders_general_mean_stud = []
    borders_general_disp = []
    print("Для вероятности p = ", p)

    for a in all_array:
        # Расчёт мат ожидания, дисперсии, сред.квадрат. отклонения для каждой заданной вероятности
        mat, disp, sigma = define_characteristics(a)
        m.append(mat)
        d.append(disp)
        sigma_array.append(sigma)
        # Расчёт границ доверительного интервала для генерального среднего
        # norm_mean_borders, stud_mean_borders = general_mean(p=p, sequence_mean=mat, sigma=sigma, n=len(a))
        lognorm_mean_borders = general_mean(p=p, sequence_mean=mat, sigma=sigma, n=len(a))
        borders_general_mean_lognorm.append(lognorm_mean_borders)
        # borders_general_mean_stud.append(stud_mean_borders)
        # Расчёт границ доверительного интервала для дисперсии
        disp_borders = general_disp(p=p, n=len(a), sigma=sigma)
        borders_general_disp.append(disp_borders)

        print(f"При n = {len(a)}:\n"
              f"M = {mat}, S = {sigma},\n"
              f"M_max (lognorm) = {lognorm_mean_borders[1]}, M_min (lognorm) = {lognorm_mean_borders[0]},\n"
              f"S_max = {np.sqrt(disp_borders[1])}, S_min = {np.sqrt(disp_borders[0])}\n")
              # f"M_max (stud) = {stud_mean_borders[1]}, M_min (stud) = {stud_mean_borders[0]}\n\n")

    mat_sred = sum(m) / len(m)
    sigma_sred = np.sqrt((4 * (sigma_array[0] ** 2) + 9 * (sigma_array[1] ** 2) + 14 * (sigma_array[2] ** 2) + 29 * (
                sigma_array[3] ** 2) + 39 * (sigma_array[4] ** 2) + 49 * (sigma_array[5] ** 2)) / 138)

    print(f"M_s = {mat_sred}, S_s = {sigma_sred}")
    print("----------------------------------------------------------------")

    min_mean_lognorm = [x[0] for x in borders_general_mean_lognorm]
    max_mean_lognorm = [x[1] for x in borders_general_mean_lognorm]
    # min_mean_stud = [x[0] for x in borders_general_mean_stud]
    # max_mean_stud = [x[1] for x in borders_general_mean_stud]

    min_disp = [np.sqrt(x[0]) for x in borders_general_disp]
    max_disp = [np.sqrt(x[1]) for x in borders_general_disp]

    plt.plot(n, min_mean_lognorm, label="M_min[i]_lognorm", linestyle="--")
    plt.plot(n, max_mean_lognorm, label="M_max[i]_lognorm", linestyle="--")
    plt.plot(n, [mat_sred] * len(n), label="M_s[i]", linestyle="-.")
    plt.plot(n, m, label="M[i]", lw=2.5)
    plt.title(f"Доверительные интервалы мат.ожидания \n (квантили логонормального распределения) p = {p}")
    plt.legend()
    plt.xlim(left=0, right=50)
    plt.grid()
    plt.show()

    # plt.plot(n, min_mean_stud, label="M_min[i]_Student", linestyle="--")
    # plt.plot(n, max_mean_stud, label="M_max[i]_Student", linestyle="--")
    # plt.plot(n, m, label="M[i]", lw=2.5)
    # plt.title(f"Доверительные интервалы мат.ожидания \n (квантили распределения Стьюдента) p = {p}")
    # plt.legend()
    # plt.xlim(left=5, right=20)
    # plt.grid()
    # plt.show()

    plt.plot(n, min_disp, label="S_min[i]", linestyle="--")
    plt.plot(n, max_disp, label="S_max[i]", linestyle="--")
    plt.plot(n, [sigma_sred] * len(n), label="S_s[i]", linestyle="-.")
    plt.plot(n, sigma_array, label="S[i]", lw=2.5)
    plt.title(f"Доверительные интервалы для сред.квадратичного отклонения \n p = {p}")
    plt.legend()
    plt.xlim(left=0, right=50)
    plt.grid()
    plt.show()
