from random import random
import matplotlib.pyplot as plt
import numpy as np


def generate_sequence(n, k):
    sequence = []
    for i in range(n):
        summary = 0
        for j in range(len(k)):
            a = 0
            b = k[j]
            summary += (b - a) * random() + a
        sequence.append(summary)
    return sequence


def define_error(sequences, n, k):
    m_t = (k[0] + 0) / 2 + (k[1] + 0) / 2 + (k[2] + 0) / 2 + (k[3] + 0) / 2
    d_t = (k[0] + 0) ** 2 / 12 + (k[1] + 0) ** 2 / 12 + (k[2] + 0) ** 2 / 12 + (k[3] + 0) ** 2 / 12
    sigma_t = np.sqrt(d_t)
    m_array = []
    sigma_array = []
    s_m_array = []
    s_d_array = []
    s_sigma_array = []
    for i in range(len(n)):
        m = sum(sequences[i]) / n[i]
        x_2 = 0
        for j in range(n[i]):
            x_2 += sequences[i][j] ** 2
        d = ((x_2 / n[i]) - m ** 2) * (n[i] / (n[i] - 1))
        sigma = np.sqrt(d)

        m_array.append(m)
        sigma_array.append(sigma)

        s_m = (abs(m - m_t) / m_t) * 100
        s_d = (abs(d - d_t) / d_t) * 100
        s_sigma = (abs(sigma - sigma_t) / sigma_t) * 100
        s_m_array.append(s_m)
        s_d_array.append(s_d)
        s_sigma_array.append(s_sigma)

    plt.plot(n, s_m_array, label=f'Математическое ожидание для {n} элементов')
    plt.title(f'График ошибки математического ожидания')
    plt.show()
    plt.plot(n, s_d_array, label=f'Дисперсия для {n} элементов')
    plt.title(f'График ошибки дисперсии')
    plt.show()
    plt.plot(n, s_sigma_array, label=f'Среднее квадратичное отклонение для {n} элементов')
    plt.title(f'График ошибки среднего квадратичного отклонения')
    plt.show()

    return m_t, sigma_t, m_array, sigma_array


def relative_frequencies(sequence, a, b, m):
    frequencies = [0] * m
    sequence_step = (b - a) / m
    left_border = a
    right_border = a + sequence_step
    for i in range(m):
        for j in sequence:
            if left_border <= j < right_border:
                frequencies[i] += 1
        frequencies[i] = frequencies[i] / len(sequence)
        left_border += sequence_step
        right_border += sequence_step
    return frequencies, sequence_step


n = [10, 20, 50, 100, 200, 500, 10 ** 3]
k = [1, 2, 5, 4]
sequences = []
for i in range(7):
    sequences.append(generate_sequence(n[i], k))
m, sigma, m_array, sigma_array = define_error(sequences, n, k)
for i in range(7):
    frequencies, sequence_step = relative_frequencies(sequences[i], 0, sum(k), 10)

    xdata = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    ydata = frequencies
    plt.bar(xdata, ydata)
    plt.title(f'Гистограмма относительных частот для {n[i]} элементов')

    x = np.arange(0.0, sum(k), 0.01)
    y = []
    y_exp = []
    for j in range(len(x)):
        y.append(1 / (sigma * np.sqrt(2 * np.pi)) * np.exp(-0.5 * ((x[j] - m) / sigma) ** 2))
        y_exp.append(1 / (sigma_array[i] * np.sqrt(2 * np.pi)) * np.exp(-0.5 * ((x[j] - m_array[i]) / sigma_array[i]) ** 2))
    plt.plot(x, y, label='Функция плотности распределения для нормального закона.')
    plt.plot(x, y_exp, label='Функция плотности распределения для нормального закона (экспериментальные значения).', color='r')
    plt.show()

    # Площади гистограмм
    area = 0
    for j in range(len(frequencies)):
        area += frequencies[j]

    print(f'Для {n[i]} элементов:')
    print("Площадь гистограмм:", area)
    print("Площадь под теоретическим графиком:", np.trapezoid(y, x))
    print("Площадь под экспериментальным графиком:", np.trapezoid(y_exp, x))
    print('----------------------------------------------------------------')

